---
id: aip-business-salesfollowup-141
title: 销售线索的记录与自动跟进
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part III > Tracking and Closing Sales; lines
  770–773; Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-email-137
---

# aip-business-salesfollowup-141: 销售线索的记录与自动跟进

## Learning Objective

能够解释“销售线索的记录与自动跟进”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part III > Tracking and Closing Sales 中围绕销售线索的记录与自动跟进的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part III > Tracking and Closing Sales。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕客户关系管理（customer relationship management, CRM）展开。作者把记录客户与采购复杂 CRM 区分开，并用试用后的邮件序列说明自动跟进。工具规模应服务于实际销售过程，而不是因为存在成熟软件就照搬复杂流程。

## Logical Path

1. 先标记线索所在阶段
2. 再记录需要的信息
3. 最后安排与阶段有关的跟进

## Key Terms

- 客户关系管理（`customer relationship management, CRM`）：记录和组织客户信息及销售跟进的过程。

## Example

原文例子：试用几天后提供使用提示、到期前发出提醒。它展示跟进可围绕客户阶段触发，而非反复人工冷联系。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part III > Tracking and Closing Sales; lines 770–773; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
