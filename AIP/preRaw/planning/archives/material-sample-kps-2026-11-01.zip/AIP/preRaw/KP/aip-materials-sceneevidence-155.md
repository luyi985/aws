---
id: aip-materials-sceneevidence-155
title: 图像描述中的可见事实与推断
status: pending
sources:
- AIP/preRaw/AIP-Materials/cdk/images/kid_and_pigeons.jpeg — entire image, 2138 ×
  1140 pixels
- AIP/preRaw/AIP-Materials/cdk/images/penguins.jpeg — entire image, 1599 × 1145 pixels
- AIP/preRaw/AIP-Materials/cdk/images/swans.jpeg — entire image, 1250 × 1000 pixels
dependencies: []
---

# aip-materials-sceneevidence-155: 图像描述中的可见事实与推断

## Learning Objective

能够对三张样图分别给出有图像证据的场景描述，并识别人物身份、地点或拍摄目的等无依据推断。

## Scope

- Included: 人物、鸟类群体、地面或水雪环境、空间关系与遮挡。
- Excluded: 人物识别、精确物种鉴定、地理定位和未运行模型的标签预测。

## Source Context

cdk/images 的三张 JPEG 均已完整解码并目视检查；文件名可帮助定位，但不替代图像本身。

## Knowledge Point

视觉依据（visual grounding）要求每项描述能在图像中找到支持。第一张可见孩子与鸽群，第二张可见蹲下的人、企鹅和雪地，第三张可见岸边人物与水鸟。描述对象及关系不需要推断人物身份或具体地点；遮挡和重叠也会限制精确计数。

## Logical Path

1. 先不依赖文件名观察主体与背景。
2. 再描述人物、鸟群和环境的空间关系。
3. 区分直接可见、合理但未证实的推断与无法确认的信息。
4. 用三张图比较描述粒度，避免把粗粒度标签误当完整理解。

## Key Terms

- 视觉依据（`visual grounding`）：用图像中实际可见的证据支持文字描述。
- 遮挡（`occlusion`）：对象的一部分被其他对象挡住。

## Example

图像例子：penguins.jpeg 支持“雪地中有人与多只企鹅”，但图像本身不足以确定人物姓名或拍摄国家。swans.jpeg 还可见岸边人物和多种外观的水鸟；不能把文件名当作每只鸟都已被精确鉴定的证据。三图共同展示可见事实与额外推断的边界。

## Sources

- `AIP/preRaw/AIP-Materials/cdk/images/kid_and_pigeons.jpeg — entire image, 2138 × 1140 pixels`：孩子、鸽群及地面环境的可见证据。
- `AIP/preRaw/AIP-Materials/cdk/images/penguins.jpeg — entire image, 1599 × 1145 pixels`：人物、企鹅及雪地的可见证据。
- `AIP/preRaw/AIP-Materials/cdk/images/swans.jpeg — entire image, 1250 × 1000 pixels`：岸边人物、水面与鸟群的可见证据。
