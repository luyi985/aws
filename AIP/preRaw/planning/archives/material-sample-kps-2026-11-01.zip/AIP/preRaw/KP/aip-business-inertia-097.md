---
id: aip-business-inertia-097
title: 识别职业惯性对选择的影响
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part I > Overcoming Inertia; Career Indoctrination;
  lines 124–129; 141–147; Windows-1252 decoding
dependencies:
- aip-business-evidence-096
---

# aip-business-inertia-097: 识别职业惯性对选择的影响

## Learning Objective

能够解释“识别职业惯性对选择的影响”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part I > Overcoming Inertia; Career Indoctrination 中围绕识别职业惯性对选择的影响的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part I > Overcoming Inertia; Career Indoctrination。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕职业惯性（career inertia）展开。作者认为长期遵循既定职业路径可能使人不再主动比较其他选择。这个观点用于提出值得检查的决策假设，并不证明每位雇员都应该创业。

## Logical Path

1. 先找到默认职业路径
2. 再写出选择背后的假设
3. 最后区分心理惯性和真实约束

## Key Terms

- 职业惯性（`career inertia`）：因熟悉既有路径而不再主动比较选择的倾向。

## Example

示意：一个人说“有家庭就只能受雇”，可先列出其真正的收入和时间约束，再看结论是否成立。这展示把习惯性的判断拆成可检查的前提。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part I > Overcoming Inertia; Career Indoctrination; lines 124–129; 141–147; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
