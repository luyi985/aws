---
id: aip-business-evidence-096
title: 区分商业自述、建议与外部证据
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Disclaimer; Preface; Acknowledgments; About
  the Author; numbered endnotes; lines 1–119; 874–918; Windows-1252 decoding
dependencies: []
---

# aip-business-evidence-096: 区分商业自述、建议与外部证据

## Learning Objective

能够解释“区分商业自述、建议与外部证据”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Disclaimer; Preface; Acknowledgments; About the Author; numbered endnotes 中围绕区分商业自述、建议与外部证据的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Disclaimer; Preface; Acknowledgments; About the Author; numbered endnotes。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕证据来源（evidence provenance）展开。作者把个人创业经历作为全书出发点，也引用统计、列出延伸阅读并承认结果依赖个人条件。学习时要区分亲历叙述、作者主张和需要独立核查的外部数据；参考书目不表示那些书的完整内容已被本地材料包含。

## Logical Path

1. 先辨认作者与写作年代
2. 再区分自述、主张和引文
3. 最后检查结论能否外推到其他人

## Key Terms

- 证据来源（`evidence provenance`）：说明论据来自亲历、主张还是外部材料的信息。

## Example

示意示例：书中回顾 2012–2014 年的公司收入属于作者历史自述，不能直接转换成读者创业后的预期收益。这展示论据类型与可推广范围的区别。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Disclaimer; Preface; Acknowledgments; About the Author; numbered endnotes; lines 1–119; 874–918; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
