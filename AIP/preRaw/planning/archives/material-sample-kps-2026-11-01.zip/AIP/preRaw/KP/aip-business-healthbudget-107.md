---
id: aip-business-healthbudget-107
title: 把医疗保障转换纳入成本模型
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part I > Planning for Health Care; lines 232–239;
  Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-cashreserve-106
---

# aip-business-healthbudget-107: 把医疗保障转换纳入成本模型

## Learning Objective

能够解释“把医疗保障转换纳入成本模型”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part I > Planning for Health Care 中围绕把医疗保障转换纳入成本模型的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part I > Planning for Health Care。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕自付额（deductible）展开。作者在 2015 年美国背景下区分持续保费与可能的一次性自付支出，解释只预算常规生活费为何可能漏项。这里仅阅读成本结构；当年的金额、制度与法律说法不作为当前健康或保险建议。

## Logical Path

1. 先确认制度与年代
2. 再区分持续和事件性支出
3. 最后检查储备模型的遗漏项

## Key Terms

- 自付额（`deductible`）：在保险模型中由个人承担、不能仅用保费代表的支出项目。

## Example

示意：模型中每月保费与一次潜在自付额占据不同栏目，即使两者都与保险有关也不能只记一项。这展示持续成本和突发支出的区别。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part I > Planning for Health Care; lines 232–239; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
