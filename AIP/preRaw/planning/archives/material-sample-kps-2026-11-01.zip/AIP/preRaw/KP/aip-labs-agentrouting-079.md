---
id: aip-labs-agentrouting-079
title: Agent Squad 按职责路由请求
status: pending
sources:
- AIP/preRaw/AIP-Materials/AgentsLab/squad_demo.py — lines 54–96 and 114–137
dependencies:
- aip-agentic-multiagent-hitl-073
- aip-labs-agentadapter-080
---

# aip-labs-agentrouting-079: Agent Squad 按职责路由请求

## Learning Objective

能够从代理描述、分类器和 route_request 调用解释请求怎样被分派，并定位实际返回的代理名称。

## Scope

- Included: 候选代理注册、职责描述、BedrockClassifier、route_request 和路由元数据。
- Excluded: 并行协作、人工审批、分类准确率评估和生产会话隔离。

## Source Context

squad_demo.py 注册一个工具代理和一个通用问答代理，由分类器选择处理者；它不是两个代理顺序完成所有任务的示例。

## Knowledge Point

请求路由（request routing）根据问题和候选职责选择一个代理。示例把计算、时间和关键词工具能力写入 Strands 代理描述，把普通问题交给另一个 Bedrock 代理，并使用独立的 BedrockClassifier。返回 metadata.agent_name 用于显示选择结果；描述本身不保证每次分类正确。

## Logical Path

1. 先区分两个候选代理和独立分类器的角色。
2. 读取候选代理的 name 与 description。
3. 追踪 add_agent 到 route_request 的调用。
4. 查看返回的 agent_name 与 output，区分路由结果和业务回答。

## Key Terms

- 分类器（`classifier`）：根据输入与职责信息选择处理者的组件。
- 路由元数据（`routing metadata`）：记录本次请求被交给谁等信息的数据。

## Example

示意示例：输入“现在几点”时，工具代理的 description 提供了 current time 线索；输入一般知识问题时，通用代理的 description 更匹配。运行后应核对输出的 Chosen agent，而不能仅凭设计意图宣称路由成功。

## Sources

- `AIP/preRaw/AIP-Materials/AgentsLab/squad_demo.py — lines 54–96 and 114–137`：候选职责、分类器设置、代理注册及路由结果显示。
