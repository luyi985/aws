---
id: aip-business-productreuse-147
title: 从现有客户与资产寻找新产品
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part III > Finding the Ideas; lines 836–843;
  Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-mvp-114
- aip-business-nichevalidation-110
---

# aip-business-productreuse-147: 从现有客户与资产寻找新产品

## Learning Objective

能够解释“从现有客户与资产寻找新产品”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part III > Finding the Ideas 中围绕从现有客户与资产寻找新产品的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part III > Finding the Ideas。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕资产复用（asset reuse）展开。作者建议从已有客户未解决的问题和现有生产资产出发寻找扩展机会，并用 SDK 衍生产品举例。复用降低部分初始投入，不会自动证明新市场存在需求。

## Logical Path

1. 先收集现有客户问题
2. 再识别可复用资产
3. 最后验证新产品与新购买者

## Key Terms

- 资产复用（`asset reuse`）：将已有技术、流程或渠道用于新交付。

## Example

原文例子：用已有图形 SDK 制作面向飞行模拟爱好者的附加产品。它展示技术资产可以服务新客户，但仍需新的产品验证。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part III > Finding the Ideas; lines 836–843; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
