---
id: aip-labs-strandsinvocation-075
title: Strands 单次请求的代码执行路径
status: pending
sources:
- AIP/preRaw/AIP-Materials/AgentsLab/strandsagent.py — lines 1–59, Agent construction
  and __main__
- AIP/preRaw/AIP-Materials/AgentsLab/requirements.txt — lines 1–3
dependencies:
- aip-agentic-strands-025
---

# aip-labs-strandsinvocation-075: Strands 单次请求的代码执行路径

## Learning Objective

能够从示例代码追踪工具注册、代理创建、请求输入和结果输出，区分代码明确设置的配置与 SDK 默认值。

## Scope

- Included: Agent 构造、tools、system_prompt、单次调用与 AgentResult 的文本输出。
- Excluded: 账号初始化、默认模型的当前名称、跨会话持久化和部署操作。

## Source Context

strandsagent.py 是现有框架概念 KP 025 对应的具体代码练习；它没有显式传入模型或区域。

## Knowledge Point

本 KP 聚焦一次本地代理调用（agent invocation）的完整路径：Python 先构造带工具与系统提示的 Agent，再把任务字符串传给代理，最后打印结果。工具被注册不代表每个请求都调用全部工具。源码未写明的模型、凭证和区域配置需要在实际运行前另行确认。

## Logical Path

1. 先定位导入、工具定义和 Agent 实例的创建位置。
2. 把 tools 与 system_prompt 对应到代理可用动作和行为指令。
3. 从 __main__ 中的 message 追踪到 strandsagent(message) 和结果输出。
4. 区分可从源码确认的执行路径与尚未验证的模型访问、运行结果。

## Key Terms

- 代理调用（`agent invocation`）：把一条输入交给代理执行的过程。
- 系统提示（`system prompt`）：创建代理时设置的行为指令。

## Example

源码示例：message 同时要求查询时间、计算 3111696 / 74088 和统计 prompt；最后两行打印 result。这展示一个请求怎样进入已注册三个工具的代理并产生结果对象；源码本身不证明模型实际选择了哪些工具。

## Sources

- `AIP/preRaw/AIP-Materials/AgentsLab/strandsagent.py — lines 1–59, Agent construction and __main__`：完整的导入、工具注册、任务文本和输出路径。
- `AIP/preRaw/AIP-Materials/AgentsLab/requirements.txt — lines 1–3`：该本地材料所固定的 SDK 包版本。
