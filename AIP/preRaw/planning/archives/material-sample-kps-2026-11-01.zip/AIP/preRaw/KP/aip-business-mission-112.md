---
id: aip-business-mission-112
title: 用使命与可衡量目标约束商业计划
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part II > Writing Your Business Plan; Business
  Description and Vision; lines 354–367; Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-businessobjective-109
---

# aip-business-mission-112: 用使命与可衡量目标约束商业计划

## Learning Objective

能够解释“用使命与可衡量目标约束商业计划”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part II > Writing Your Business Plan; Business Description and Vision 中围绕用使命与可衡量目标约束商业计划的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part II > Writing Your Business Plan; Business Description and Vision。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕使命陈述（mission statement）展开。作者把商业计划当作可修正的可行路径，而非未来保证；简明使命用于说清企业擅长解决什么问题，后续目标需要可观察。目标的用途是检查计划，不是美化融资叙述。

## Logical Path

1. 先确定要解决的问题
2. 再形成清楚的使命
3. 最后用可衡量目标检查路径是否连贯

## Key Terms

- 使命陈述（`mission statement`）：简明表达企业服务谁、解决什么问题的陈述。

## Example

原文例子：Sundog 的使命围绕沉浸式户外虚拟世界，同时保留模拟、训练和娱乐等扩展空间。它展示使命可以具体又不锁死单一产品。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part II > Writing Your Business Plan; Business Description and Vision; lines 354–367; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
