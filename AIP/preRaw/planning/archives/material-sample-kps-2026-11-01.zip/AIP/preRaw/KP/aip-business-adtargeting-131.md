---
id: aip-business-adtargeting-131
title: 搜索意图与广告投放范围的匹配
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part III > Google AdWords > campaign targeting
  and keywords; lines 667–681; Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-adconversion-130
---

# aip-business-adtargeting-131: 搜索意图与广告投放范围的匹配

## Learning Objective

能够解释“搜索意图与广告投放范围的匹配”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part III > Google AdWords > campaign targeting and keywords 中围绕搜索意图与广告投放范围的匹配的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part III > Google AdWords > campaign targeting and keywords。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕否定关键词（negative keyword）展开。作者通过设备、地区、展示位置、搜索词与落地页匹配说明，便宜的点击也可能来自无关需求。该 KP 研究匹配机制，不把历史平台设置或国家判断当作当前投放规则。

## Logical Path

1. 先还原用户搜索意图
2. 再找不匹配的投放范围
3. 最后核对广告和落地页是否承接同一需求

## Key Terms

- 否定关键词（`negative keyword`）：用于排除不希望触发广告的搜索意图的词。

## Example

原文例子：SilverLining 产品名称与电影搜索混淆，产生无关点击。这展示关键词相似不等于购买意图相同。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part III > Google AdWords > campaign targeting and keywords; lines 667–681; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
