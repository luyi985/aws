---
id: aip-business-contractortrial-146
title: 用小任务验证外部承包者的交付
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part III > Finding the People; lines 831–835;
  Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-timeallocation-145
---

# aip-business-contractortrial-146: 用小任务验证外部承包者的交付

## Learning Objective

能够解释“用小任务验证外部承包者的交付”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part III > Finding the People 中围绕用小任务验证外部承包者的交付的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part III > Finding the People。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕试任务（trial task）展开。作者提出用小而清楚、费用有边界的任务检验新承包者，再决定是否扩大合作。原文关于劳动身份和税务表格的说法只作为历史文本，本 KP 关注交付验证。

## Logical Path

1. 先定义可验收任务
2. 再约定范围和投入上限
3. 最后按交付证据决定后续合作

## Key Terms

- 试任务（`trial task`）：在有限范围内检查承包者真实交付能力的任务。

## Example

示意：先约定一项可检查的小交付，而不直接委托整个产品。它展示如何用有限试验获得实际合作证据。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part III > Finding the People; lines 831–835; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
