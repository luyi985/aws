---
id: aip-business-supportfunctions-101
title: 识别离开雇主后需要承接的支持职能
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part I > Your Employer as a Security Blanket;
  lines 165–171; Windows-1252 decoding
dependencies:
- aip-business-evidence-096
---

# aip-business-supportfunctions-101: 识别离开雇主后需要承接的支持职能

## Learning Objective

能够解释“识别离开雇主后需要承接的支持职能”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part I > Your Employer as a Security Blanket 中围绕识别离开雇主后需要承接的支持职能的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part I > Your Employer as a Security Blanket。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕支持职能（support function）展开。作者列出雇主原本承接的行政、保险、会计和其他事务，说明独立经营会让责任重新分配。识别缺口不等于全部自己完成；原文也讨论购买专业帮助。

## Logical Path

1. 先列原有支持
2. 再识别转换后的责任人
3. 最后区分自办和寻求外部帮助

## Key Terms

- 支持职能（`support function`）：让核心业务能够持续进行的行政与专业支持。

## Example

示意：产品开发能力很好的人仍可能需要记账帮助。这展示业务核心技能与维持经营的支持职能并不相同。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part I > Your Employer as a Security Blanket; lines 165–171; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
