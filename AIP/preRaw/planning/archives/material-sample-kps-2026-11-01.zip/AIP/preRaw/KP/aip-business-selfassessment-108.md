---
id: aip-business-selfassessment-108
title: 把创业自评表当作能力缺口清单
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part I > Self-Assessment Quiz; lines 242–261;
  Windows-1252 decoding
dependencies:
- aip-business-evidence-096
---

# aip-business-selfassessment-108: 把创业自评表当作能力缺口清单

## Learning Objective

能够解释“把创业自评表当作能力缺口清单”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part I > Self-Assessment Quiz 中围绕把创业自评表当作能力缺口清单的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part I > Self-Assessment Quiz。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕自评启发式（self-assessment heuristic）展开。原文明说问卷不是科学测试，而是作者重视的独立工作、完成任务、沟通与自律能力清单。得分可引出待检查的能力，不应转换成创业结果预测。

## Logical Path

1. 先识别问卷测什么
2. 再把回答转为可观察行为
3. 最后检查其非科学预测的边界

## Key Terms

- 自评启发式（`self-assessment heuristic`）：帮助提出待检查问题、但不构成科学预测的自我检查方式。

## Example

示意：自评发现经常拖延交付，就进一步收集实际项目完成记录，而不是仅凭总分决定职业选择。这展示问卷如何提出问题。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part I > Self-Assessment Quiz; lines 242–261; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
