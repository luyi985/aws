---
id: aip-business-timeallocation-145
title: 用机会成本比较自动化、外包与产品开发
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part III > Building a Growth Engine; Finding
  the Time; lines 819–830; Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-scalability-102
- aip-business-projection-119
---

# aip-business-timeallocation-145: 用机会成本比较自动化、外包与产品开发

## Learning Objective

能够解释“用机会成本比较自动化、外包与产品开发”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part III > Building a Growth Engine; Finding the Time 中围绕用机会成本比较自动化、外包与产品开发的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part III > Building a Growth Engine; Finding the Time。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕机会成本（opportunity cost）展开。作者比较经营者用时间做日常任务或开发新产品的潜在价值，并要求计入现金流约束。预测的长期收益不是已实现收入，不能单独证明立即增加外包支出合理。

## Logical Path

1. 先列可替代的时间用途
2. 再比较投入与潜在回报
3. 最后检查现金和持续维护约束

## Key Terms

- 机会成本（`opportunity cost`）：选择一个用途时放弃的其他可选用途的价值。

## Example

示意：自动化每周一小时的工作也需要开发时间；先比较节省的工时和投入，再检查现金与维护成本。这展示时间回报需要完整比较。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part III > Building a Growth Engine; Finding the Time; lines 819–830; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
