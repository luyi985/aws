---
id: aip-business-naming-121
title: 企业命名中的易记性与可用性
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part II > Naming Your Business; lines 458–463;
  Windows-1252 decoding
dependencies:
- aip-business-evidence-096
---

# aip-business-naming-121: 企业命名中的易记性与可用性

## Learning Objective

能够解释“企业命名中的易记性与可用性”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part II > Naming Your Business 中围绕企业命名中的易记性与可用性的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part II > Naming Your Business。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕名称可用性（name availability）展开。作者先要求发散候选名称，再检查记忆和拼写成本、相似业务混淆及域名。原文的 .com 偏好属于当时作者建议；能注册域名不等于已经解决名称权利问题。

## Logical Path

1. 先产生多个候选
2. 再检查记忆和拼写
3. 最后把域名与名称权利分开核查

## Key Terms

- 名称可用性（`name availability`）：候选名称在相关业务与传播场景中是否可使用的待核查问题。

## Example

示意：一个易记名字可能已有相似业务使用，而一个空闲域名也可能拼写困难。这展示命名需要分别检查传播与可用性。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part II > Naming Your Business; lines 458–463; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
