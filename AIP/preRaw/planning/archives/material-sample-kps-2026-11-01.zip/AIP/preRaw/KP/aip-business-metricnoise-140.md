---
id: aip-business-metricnoise-140
title: 小样本营销数据中的随机波动与代理指标
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part III > Interpreting Your Metrics; Beware
  of Misleading Statistics; lines 762–769; 809–816; Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-measurement-139
---

# aip-business-metricnoise-140: 小样本营销数据中的随机波动与代理指标

## Learning Objective

能够解释“小样本营销数据中的随机波动与代理指标”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part III > Interpreting Your Metrics; Beware of Misleading Statistics 中围绕小样本营销数据中的随机波动与代理指标的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part III > Interpreting Your Metrics; Beware of Misleading Statistics。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕随机波动（random variation）展开。作者提醒短期少量数据可能被季节、异常流量或代理指标误导，建议结合长期趋势与实际交易检查。统计判断不能靠一次漂亮的百分比完成。

## Logical Path

1. 先检查样本量和行动定义
2. 再找季节或异常因素
3. 最后与长期交易趋势对照

## Key Terms

- 随机波动（`random variation`）：没有真实机制变化也可能出现的数据起伏。

## Example

原文例子：下载 CPA 很低的活动没有对应的预期商业结果，进一步检查流量才发现问题。这展示优化代理指标可能偏离真实目标。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part III > Interpreting Your Metrics; Beware of Misleading Statistics; lines 762–769; 809–816; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
