---
id: aip-business-professionalexit-127
title: 职业退出过程中的关系与交接
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part II > Telling Your Boss; lines 548–564;
  Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-readiness-126
---

# aip-business-professionalexit-127: 职业退出过程中的关系与交接

## Learning Objective

能够解释“职业退出过程中的关系与交接”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part II > Telling Your Boss 中围绕职业退出过程中的关系与交接的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part II > Telling Your Boss。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕职业交接（professional transition）展开。作者把离职沟通、联系方式、个人物品和雇主设备的处理视为维持职业关系的一部分。书中的保险和就业流程仅是当时美国经历，不用于推导其他地区的现行权利。

## Logical Path

1. 先识别必须交接的事项
2. 再安排沟通与记录
3. 最后检查退出后的联系和责任

## Key Terms

- 职业交接（`professional transition`）：改变职业关系时处理沟通、物品、信息和责任的过程。

## Example

示意：告知可联系地址、归还设备并保持交接记录，解决的是退出后的连续性，而不只是完成一次告别谈话。这展示退出过程的具体环节。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part II > Telling Your Boss; lines 548–564; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
