---
id: aip-business-bookkeeping-122
title: 业务收支记录与个人收支分离
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part II > Obtaining Licenses and Tax Planning;
  lines 472–476; Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-businessstructure-117
---

# aip-business-bookkeeping-122: 业务收支记录与个人收支分离

## Learning Objective

能够解释“业务收支记录与个人收支分离”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part II > Obtaining Licenses and Tax Planning 中围绕业务收支记录与个人收支分离的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part II > Obtaining Licenses and Tax Planning。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕收支记录（bookkeeping）展开。作者将独立业务账户、收入支出记录和与会计沟通联系起来，强调在经营初期就保留可追溯数据。文中的美国申报、扣除与软件建议是历史语境，本 KP 不推导实际税务结论。

## Logical Path

1. 先区分业务与个人交易
2. 再保存交易证据
3. 最后用一致记录支持后续分析

## Key Terms

- 收支记录（`bookkeeping`）：有一致依据地记录业务收入、支出及相关交易。

## Example

示意：把一项业务订阅与家庭消费分别记录，能追踪经营支出的来源。它展示可解释的账目是分析输入，而非只在报税时拼凑数字。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part II > Obtaining Licenses and Tax Planning; lines 472–476; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
