---
id: aip-labs-agentadapter-080
title: 将 Strands 结果适配为 Agent Squad 消息
status: pending
sources:
- AIP/preRaw/AIP-Materials/AgentsLab/squad_demo.py — lines 3–51 and 99–111
- AIP/preRaw/AIP-Materials/AgentsLab/requirements.txt — lines 1–3
dependencies:
- aip-labs-strandsinvocation-075
---

# aip-labs-agentadapter-080: 将 Strands 结果适配为 Agent Squad 消息

## Learning Objective

能够解释 StrandsAdapterAgent 怎样满足目标接口，并指出原始接口参数在适配过程中的保留与丢失。

## Scope

- Included: Agent 子类、process_request、AgentResult 到 ConversationMessage 的转换及参数使用边界。
- Excluded: 自动历史同步、异步调度优化和 SDK 源码实现。

## Source Context

squad_demo.py 的自定义 adapter 是两个框架之间的接缝；当前 requirements.txt 未声明 agent_squad 对应依赖。

## Knowledge Point

适配器（adapter）把一个组件的调用与返回格式转成另一个框架所需的接口。这里的 async process_request 直接同步调用全局 Strands 代理，再把 str(result) 放进 assistant 消息。user_id、session_id 和 chat_history 没有传给 Strands，因此不能从目标接口的存在推断已有用户隔离。

## Logical Path

1. 先读目标 Agent 子类要求实现的方法签名。
2. 检查哪些入参真正进入 Strands 调用。
3. 追踪结果文本怎样包装成 ConversationMessage。
4. 区分异步函数声明、同步执行和未处理的历史或身份参数。

## Key Terms

- 适配器（`adapter`）：在不同组件接口之间转换调用和数据的代码。
- 会话历史（`chat history`）：此前交互的消息集合。

## Example

源码边界示例：两个不同 session_id 的请求都会执行同一条 strands_sdk_agent(input_text)，没有把各自的 chat_history 传入。这个对照说明消息格式兼容与会话隔离是不同问题；它不等于已经证明发生了跨用户数据泄漏。

## Sources

- `AIP/preRaw/AIP-Materials/AgentsLab/squad_demo.py — lines 3–51 and 99–111`：全局代理导入、适配方法和消息提取。
- `AIP/preRaw/AIP-Materials/AgentsLab/requirements.txt — lines 1–3`：目前声明的依赖集合中未列出 Agent Squad。
