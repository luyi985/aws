---
id: aip-business-mvp-114
title: 最小可行产品的范围与质量边界
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part II > Description of the Product; Developing
  Your Business on the Side; lines 375–378; 453–455; Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-nichevalidation-110
---

# aip-business-mvp-114: 最小可行产品的范围与质量边界

## Learning Objective

能够解释“最小可行产品的范围与质量边界”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part II > Description of the Product; Developing Your Business on the Side 中围绕最小可行产品的范围与质量边界的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part II > Description of the Product; Developing Your Business on the Side。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕最小可行产品（minimum viable product, MVP）展开。作者用客户需要限定首发功能，反对不断加入功能推迟上市，也反对把最小范围理解成粗糙或失效的产品。原型需获得外部反馈，才能帮助区分需求问题和质量问题。

## Logical Path

1. 先找核心客户需要
2. 再界定最小完整功能
3. 最后用外部反馈检查质量边界

## Key Terms

- 最小可行产品（`minimum viable product, MVP`）：足以服务目标客户核心需要并获得验证的最小完整产品。

## Example

示意：首发只解决一个客户问题，但该流程仍可正常完成；删除非关键功能与保留严重故障不是同一种“精简”。这展示范围和质量是两条轴。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part II > Description of the Product; Developing Your Business on the Side; lines 375–378; 453–455; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
