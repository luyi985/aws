---
id: aip-business-scalability-102
title: 可复制产品与按小时收费的扩展边界
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part I > Unlimited Growth Potential; Investing
  in Yourself; No Dependencies; Part II > Planning the Ideal Lifestyle Business; Sundog
  case; lines 174–189; 287–301; 302–319; 333–334; Windows-1252 decoding
dependencies:
- aip-business-evidence-096
---

# aip-business-scalability-102: 可复制产品与按小时收费的扩展边界

## Learning Objective

能够解释“可复制产品与按小时收费的扩展边界”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part I > Unlimited Growth Potential; Investing in Yourself; No Dependencies; Part II > Planning the Ideal Lifestyle Business; Sundog case 中围绕可复制产品与按小时收费的扩展边界的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part I > Unlimited Growth Potential; Investing in Yourself; No Dependencies; Part II > Planning the Ideal Lifestyle Business; Sundog case。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕可扩展性（scalability）展开。作者用软件许可说明，部分产品的新增销售不必逐单消耗同等开发时间，而按小时收费受可用工时限制。这不意味着数字产品无维护成本或不依赖客户与供应者；原文随后讨论支持、外包与依赖。

## Logical Path

1. 先确定销售单位
2. 再看增加一笔销售需要多少个人工时
3. 最后计入持续支持与外部依赖

## Key Terms

- 可扩展性（`scalability`）：新增需求与所需资源不必保持相同比例增长的特性。

## Example

原文例子：Sundog 的一次修复可供多个许可客户使用，而一个小时的咨询不能同时出售给所有客户。这展示新增销售与个人工时的关系。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part I > Unlimited Growth Potential; Investing in Yourself; No Dependencies; Part II > Planning the Ideal Lifestyle Business; Sundog case; lines 174–189; 287–301; 302–319; 333–334; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
