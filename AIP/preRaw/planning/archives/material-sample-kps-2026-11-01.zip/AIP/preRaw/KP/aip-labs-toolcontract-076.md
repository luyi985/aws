---
id: aip-labs-toolcontract-076
title: 自定义 Strands 工具的输入输出契约
status: pending
sources:
- AIP/preRaw/AIP-Materials/AgentsLab/strandsagent.py — lines 5–23 and 48–53, count_keyword
  and sample text
dependencies:
- aip-labs-strandsinvocation-075
---

# aip-labs-toolcontract-076: 自定义 Strands 工具的输入输出契约

## Learning Objective

能够根据 count_keyword 的签名、说明和分支写出工具调用的预期结果，并识别子串统计与整词统计的差异。

## Scope

- Included: @tool、类型标注、docstring、空参数处理和不区分大小写的子串计数。
- Excluded: 自然语言分词、工具服务鉴权和 SDK 内部 schema 生成实现。

## Source Context

strandsagent.py 用同一个 count_keyword 函数展示工具声明和工具实现；题目中的 word 与实现中的 count 不完全等价。

## Knowledge Point

工具契约（tool contract）要把可调用参数与返回值说清楚，也要核对实际代码是否符合描述。count_keyword 将输入转为小写，再调用字符串 count，因此统计的是不重叠子串；非字符串参数或空 keyword 返回 0。声明工具不能替代对这些边界的理解。

## Logical Path

1. 先读函数签名和 docstring，确定输入及返回类型。
2. 检查类型与空字符串分支，确认提前返回条件。
3. 再用 lower().count() 推出真正的匹配单位。
4. 用包含复数词的文本检查题意与实现之间的边界。

## Key Terms

- 工具契约（`tool contract`）：调用者与工具之间关于输入、输出和含义的约定。
- 子串（`substring`）：字符串中连续的一段字符。

## Example

示意示例：count_keyword("Prompt prompts", "prompt") 的实现结果为 2，count_keyword("Prompt", "") 返回 0。第一个结果说明 prompts 中的 prompt 也会被计入，不能把该工具直接当作严格的整词计数器。

## Sources

- `AIP/preRaw/AIP-Materials/AgentsLab/strandsagent.py — lines 5–23 and 48–53, count_keyword and sample text`：函数签名、边界分支、实际计数表达式与题目文本。
