---
id: aip-business-acquisitionplan-118
title: 把客户发现与购买连接成获客路径
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part II > Marketing and Sales Strategy; Key
  Points > Can I automate sales and marketing?; lines 342–344; 386–396; Windows-1252
  decoding
dependencies:
- aip-business-evidence-096
- aip-business-marketsizing-113
---

# aip-business-acquisitionplan-118: 把客户发现与购买连接成获客路径

## Learning Objective

能够解释“把客户发现与购买连接成获客路径”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part II > Marketing and Sales Strategy; Key Points > Can I automate sales and marketing? 中围绕把客户发现与购买连接成获客路径的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part II > Marketing and Sales Strategy; Key Points > Can I automate sales and marketing?。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕获客路径（customer acquisition path）展开。作者从客户在哪里出现、如何了解产品、怎样评估以及如何完成购买倒推营销活动。重点是各步骤是否连接，而不是购买越多渠道越好。

## Logical Path

1. 先定位目标客户
2. 再连接发现与评估
3. 最后检查购买和跟进步骤

## Key Terms

- 获客路径（`customer acquisition path`）：潜在客户从发现产品到评估和购买的步骤。

## Example

示意：行业文章带来访问，试用页让人评估，随后提供清楚的购买步骤。它展示渠道流量必须能走到实际交易。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part II > Marketing and Sales Strategy; Key Points > Can I automate sales and marketing?; lines 342–344; 386–396; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
