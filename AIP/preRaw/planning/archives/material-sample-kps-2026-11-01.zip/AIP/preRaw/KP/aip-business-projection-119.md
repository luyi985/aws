---
id: aip-business-projection-119
title: 商业预测中的规模、渗透率与成本假设
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part II > Financial Management; lines 397–431;
  Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-marketsizing-113
- aip-business-pricing-115
- aip-business-revenuemodel-116
---

# aip-business-projection-119: 商业预测中的规模、渗透率与成本假设

## Learning Objective

能够解释“商业预测中的规模、渗透率与成本假设”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part II > Financial Management 中围绕商业预测中的规模、渗透率与成本假设的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part II > Financial Management。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕市场渗透率（market penetration）展开。作者把市场人数、预计渗透率和每位客户年支出相乘估算收入，再减去经营支出检查计划。公式可以计算，输入仍是假设；其历史税务比例不用于当前个人预测。

## Logical Path

1. 先列市场与价格输入
2. 再计算假设收入和支出
3. 最后检查关键假设变化

## Key Terms

- 市场渗透率（`market penetration`）：假设市场中实际成为客户的比例。

## Example

示意：1000 个潜在客户、假设 2% 购买、每人年付 100，模型收入为 2000；购买率改变时结论也会改变。这展示可计算性与可靠性不同。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part II > Financial Management; lines 397–431; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
