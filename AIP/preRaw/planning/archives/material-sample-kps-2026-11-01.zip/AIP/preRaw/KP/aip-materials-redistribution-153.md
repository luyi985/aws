---
id: aip-materials-redistribution-153
title: Apache 2.0 文本中的再分发条件
status: pending
sources:
- AIP/preRaw/AIP-Materials/aws-cicd/codedeploy/SampleApp_Linux/LICENSE.txt — section
  4, Redistribution, clauses (a)–(d)
dependencies:
- aip-materials-licensegrant-152
---

# aip-materials-redistribution-153: Apache 2.0 文本中的再分发条件

## Learning Objective

能够从许可第 4 节逐项识别随分发携带的许可、修改说明和归属信息，并区分条件性 NOTICE 要求。

## Scope

- Included: 第 4 节 (a)–(d)、源形式归属说明、修改标记和 NOTICE 的条件。
- Excluded: 给实际发布作法律合规认证，或声称当前材料包含未发现的 NOTICE。

## Source Context

本地 LICENSE.txt 含完整再分发条款；压缩包与展开目录包含同一许可文件。

## Knowledge Point

再分发条件（redistribution condition）描述把作品交给其他接收者时附带的文本要求。第 4 节分别说明许可副本、修改说明、源形式归属信息和原作品含 NOTICE 时的处理。这里识别的是原文条件，不把“未在本地看到 NOTICE”推导为所有上游作品都没有通知要求。

## Logical Path

1. 先确定讨论的是复制使用还是向其他人分发。
2. 按 (a)–(d) 列出独立条件。
3. 找出 NOTICE 条件何时才触发。
4. 核对材料实际包含哪些文件，保留未知上游范围。

## Key Terms

- 再分发（`redistribution`）：把作品或其修改版本再交付给其他接收者。
- 归属说明（`attribution notice`）：表明作者或相关来源的信息。

## Example

文本对照示例：修改文件的说明与分发许可副本是两个分别列出的条件；提供许可副本不能据此省略修改说明。这展示条款需要逐项检查。

## Sources

- `AIP/preRaw/AIP-Materials/aws-cicd/codedeploy/SampleApp_Linux/LICENSE.txt — section 4, Redistribution, clauses (a)–(d)`：许可副本、修改声明、保留通知及条件性的 NOTICE 要求。
