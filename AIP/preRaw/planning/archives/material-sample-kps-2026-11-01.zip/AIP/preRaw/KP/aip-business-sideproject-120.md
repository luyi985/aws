---
id: aip-business-sideproject-120
title: 在保留主业时验证产品假设
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part II > Check Your Employment Agreement; Developing
  Your Business on the Side; lines 434–457; Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-mvp-114
---

# aip-business-sideproject-120: 在保留主业时验证产品假设

## Learning Objective

能够解释“在保留主业时验证产品假设”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part II > Check Your Employment Agreement; Developing Your Business on the Side 中围绕在保留主业时验证产品假设的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part II > Check Your Employment Agreement; Developing Your Business on the Side。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕分阶段验证（staged validation）展开。作者把主业履责、独立使用个人时间设备、客户访谈和原型反馈组织成逐步验证路径。关于就业协议的段落提出需要核查的边界，不在此判断任何现行合同是否有效。

## Logical Path

1. 先确认工作与资源边界
2. 再缩小产品试验
3. 最后根据客户反馈决定下一步

## Key Terms

- 分阶段验证（`staged validation`）：先通过小步骤收集证据，再决定是否增加投入。

## Example

示意：先访谈潜在客户，再在个人设备上做小范围原型，得到反馈后才扩大投入。这展示每一步都增加证据而非只增加工时。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part II > Check Your Employment Agreement; Developing Your Business on the Side; lines 434–457; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
