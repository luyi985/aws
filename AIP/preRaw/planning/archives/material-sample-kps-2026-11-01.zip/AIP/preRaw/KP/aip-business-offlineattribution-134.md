---
id: aip-business-offlineattribution-134
title: 线下营销的来源识别
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part III > Basics of Offline Marketing; lines
  702–710; Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-acquisitionplan-118
---

# aip-business-offlineattribution-134: 线下营销的来源识别

## Learning Objective

能够解释“线下营销的来源识别”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part III > Basics of Offline Marketing 中围绕线下营销的来源识别的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part III > Basics of Offline Marketing。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕来源识别（source attribution）展开。作者讨论专业刊物、展会和邮寄宣传，重点是如何把线下接触与后续咨询或购买连接。专属链接、电话或询问来源可以提供线索，但仍需解释其测量范围。

## Logical Path

1. 先定位线下触达人群
2. 再设计可识别入口
3. 最后区分响应和最终交易

## Key Terms

- 来源识别（`source attribution`）：辨认咨询或交易从哪个接触入口而来的过程。

## Example

原文例子：为某张广告使用专属 URL，从该地址的访问观察响应。这展示线下投放也需要可追踪入口。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part III > Basics of Offline Marketing; lines 702–710; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
