---
id: aip-business-marketsizing-113
title: 自下而上的市场规模估算
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part II > Definition of the Market; lines 368–374;
  Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-nichevalidation-110
---

# aip-business-marketsizing-113: 自下而上的市场规模估算

## Learning Objective

能够解释“自下而上的市场规模估算”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part II > Definition of the Market 中围绕自下而上的市场规模估算的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part II > Definition of the Market。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕自下而上估算（bottom-up estimation）展开。作者要求先描述真实购买者，再使用行业成员、相似产品与可获取数据估算人数，并扣除竞争和不购买的可能。把世界人口任取一个百分比不等于找到可接触的市场。

## Logical Path

1. 先定义购买者
2. 再寻找可计数数据
3. 最后检查预算、竞争与购买意愿

## Key Terms

- 自下而上估算（`bottom-up estimation`）：从可识别购买者和可检查数据逐步形成总体估计。

## Example

示意：从已识别的某类机构数量与预算出发，和“全球人口的 1% 都可能买”相比，前者的每一步更容易检查。这展示估算可追溯性。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part II > Definition of the Market; lines 368–374; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
