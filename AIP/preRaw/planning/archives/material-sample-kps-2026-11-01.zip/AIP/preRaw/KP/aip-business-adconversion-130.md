---
id: aip-business-adconversion-130
title: 用付费行动成本检查广告目标
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part III > Basics of Online Advertising > Google
  AdWords; lines 654–666; Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-acquisitionplan-118
---

# aip-business-adconversion-130: 用付费行动成本检查广告目标

## Learning Objective

能够解释“用付费行动成本检查广告目标”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part III > Basics of Online Advertising > Google AdWords 中围绕用付费行动成本检查广告目标的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part III > Basics of Online Advertising > Google AdWords。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕行动成本（cost per action, CPA）展开。作者把广告成本除以所选行动次数，要求检查行动是否真正接近收入。下载可作为代理指标，但不等同购买；平台界面与优化方式只按 2015 年原文研究。

## Logical Path

1. 先定义所计行动
2. 再算每次行动成本
3. 最后检查行动与实际收入的联系

## Key Terms

- 行动成本（`cost per action, CPA`）：广告费用除以按事先定义计数的行动次数。

## Example

示意：花费 100 获得 20 次下载，下载 CPA 为 5；如果没有付费购买，不能把 20 次下载都当成新客户。这展示指标定义决定含义。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part III > Basics of Online Advertising > Google AdWords; lines 654–666; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
