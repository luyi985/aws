---
id: aip-business-foundersales-143
title: 把线索搜集与技术成交分开
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part III > Beware of Hiring Salespeople; lines
  794–801; Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-acquisitionplan-118
---

# aip-business-foundersales-143: 把线索搜集与技术成交分开

## Learning Objective

能够解释“把线索搜集与技术成交分开”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part III > Beware of Hiring Salespeople 中围绕把线索搜集与技术成交分开的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part III > Beware of Hiring Salespeople。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕线索筛选（lead qualification）展开。作者区分寻找潜在客户和解答深入产品问题，认为其细分技术业务中创始人更了解产品与交易权限。这是业务条件下的分工论证，不证明所有企业都无需销售人员。

## Logical Path

1. 先区分搜集与成交环节
2. 再看各环节所需知识
3. 最后匹配任务与执行者

## Key Terms

- 线索筛选（`lead qualification`）：检查一个潜在客户是否具备相关需要和购买条件。

## Example

原文例子：外包耗时的线索搜集，再由创始人处理合格客户的技术问题。它展示销售流程可以按知识要求拆分。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part III > Beware of Hiring Salespeople; lines 794–801; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
