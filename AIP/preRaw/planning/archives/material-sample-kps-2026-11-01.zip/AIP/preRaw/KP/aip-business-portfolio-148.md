---
id: aip-business-portfolio-148
title: 持续产品组合与旧产品衰退
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part III > The Compounding Effect; lines 844–848;
  Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-productreuse-147
- aip-business-timeallocation-145
---

# aip-business-portfolio-148: 持续产品组合与旧产品衰退

## Learning Objective

能够解释“持续产品组合与旧产品衰退”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part III > The Compounding Effect 中围绕持续产品组合与旧产品衰退的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part III > The Compounding Effect。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕产品组合（product portfolio）展开。作者用多个持续收入来源相加说明增长潜力，也承认新产品失败、旧产品衰退和支持工时上限。这里描述产品收入叠加，不把它等同保证的复利投资收益。

## Logical Path

1. 先列各产品收入来源
2. 再加入衰退与失败
3. 最后检查支持能力和经营目标

## Key Terms

- 产品组合（`product portfolio`）：需要共同经营和支持的多个产品及其收入来源。

## Example

示意：两个产品的收入能相加，但旧产品减少的收入和新增支持时间也必须纳入。它展示组合效应取决于留存与容量。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part III > The Compounding Effect; lines 844–848; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
