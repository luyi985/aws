---
id: aip-business-workidentity-100
title: 职业身份变化与社交支持
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part I > Ego Protection; lines 160–164; Windows-1252
  decoding
dependencies:
- aip-business-evidence-096
---

# aip-business-workidentity-100: 职业身份变化与社交支持

## Learning Objective

能够解释“职业身份变化与社交支持”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part I > Ego Protection 中围绕职业身份变化与社交支持的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part I > Ego Protection。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕职业身份（work identity）展开。作者讨论了头衔、同事关系和认可感为什么可能阻碍职业转换，并举出维持联系和寻找同伴的办法。这里研究的是身份与社交需要，不把个人感受当成普遍心理结论。

## Logical Path

1. 先识别身份带来的满足
2. 再区分头衔和关系
3. 最后寻找能延续支持的方式

## Key Terms

- 职业身份（`work identity`）：一个人把职业角色与自我评价联系起来的方式。

## Example

示意：离开职位后仍保持原同事联系，解决的是社交连续性，不等于必须保留原来的头衔。这展示两种需要可以分别处理。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part I > Ego Protection; lines 160–164; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
