---
id: aip-business-transitionidentity-149
title: 把过去职业经验重新纳入创业叙事
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part III > Adapting to Your New Life; Survivor’s
  Guilt; lines 851–861; Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-workidentity-100
---

# aip-business-transitionidentity-149: 把过去职业经验重新纳入创业叙事

## Learning Objective

能够解释“把过去职业经验重新纳入创业叙事”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part III > Adapting to Your New Life; Survivor’s Guilt 中围绕把过去职业经验重新纳入创业叙事的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part III > Adapting to Your New Life; Survivor’s Guilt。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕身份转换（identity transition）展开。作者用自己的感受讨论职业转换后的愧疚，并把原来的工作经验重新理解为技能积累。它是个人叙述与反思路径，不是心理诊断或治疗结论。

## Logical Path

1. 先识别转换后的自我叙述
2. 再找过去经验的实际贡献
3. 最后区分个人感受与普遍结论

## Key Terms

- 身份转换（`identity transition`）：职业角色变化后重新理解自我与过去经历的过程。

## Example

原文强调过往受雇经历带来的技能有助于独立经营。它展示新选择无需把旧经历全部解释成浪费。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part III > Adapting to Your New Life; Survivor’s Guilt; lines 851–861; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
