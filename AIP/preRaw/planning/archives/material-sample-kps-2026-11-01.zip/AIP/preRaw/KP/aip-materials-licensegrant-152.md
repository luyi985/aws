---
id: aip-materials-licensegrant-152
title: Apache 2.0 文本中的授权对象与边界
status: pending
sources:
- AIP/preRaw/AIP-Materials/aws-cicd/codedeploy/SampleApp_Linux/LICENSE.txt — sections
  1–3 and 5–6
dependencies: []
---

# aip-materials-licensegrant-152: Apache 2.0 文本中的授权对象与边界

## Learning Objective

能够区分本地许可文本中的版权授权、专利授权、贡献提交与商标边界，并指出不能由许可名称单独推出的结论。

## Scope

- Included: 第 1–3、5–6 节中的定义、授权种类、贡献默认条款和商标例外。
- Excluded: 判断实际侵权、合同效力或当前法律争议；未提供的独立协议内容。

## Source Context

SampleApp_Linux 附带 Apache License Version 2.0（January 2004）；这里研究随包文本的条款结构。

## Knowledge Point

授权范围（license scope）要按对象和条件阅读。第 2 节谈版权行为，第 3 节给出有范围及终止条件的专利授权，第 5 节讨论主动提交的贡献，第 6 节限制商标使用。不能把这些不同条款压缩成“所有相关权利都无限开放”。

## Logical Path

1. 先读 Work、Contribution、Contributor 等定义。
2. 再区分版权和专利条款分别覆盖什么。
3. 检查贡献提交规则和商标例外。
4. 把文本中的授权范围与未验证的实际权利情况分开。

## Key Terms

- 授权范围（`license scope`）：许可明确允许哪些行为、针对哪些对象以及附带什么条件。

## Example

文本对照示例：第 2 节允许复制和分发等版权行为，但第 6 节没有一般性授予商标使用权。这展示获得代码许可与获得全部品牌权利不是同一结论。

## Sources

- `AIP/preRaw/AIP-Materials/aws-cicd/codedeploy/SampleApp_Linux/LICENSE.txt — sections 1–3 and 5–6`：定义、版权与专利授权、贡献提交和商标边界。
