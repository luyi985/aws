---
id: aip-business-socialpresence-138
title: 社交渠道选择中的时间机会成本
status: pending
sources:
- AIP/preRaw/AIP-Materials/book.txt — Part III > Using Social Networks; lines 743–752;
  Windows-1252 decoding
dependencies:
- aip-business-evidence-096
- aip-business-acquisitionplan-118
---

# aip-business-socialpresence-138: 社交渠道选择中的时间机会成本

## Learning Objective

能够解释“社交渠道选择中的时间机会成本”的中心判断，并用一个例子指出其成立条件或证据边界。

## Scope

- Included: Part III > Using Social Networks 中围绕社交渠道选择中的时间机会成本的机制、论据与适用边界。
- Excluded: 把作者历史经验当作当前法律、税务、医疗、投资或平台操作建议；未提供的延伸阅读全文。

## Source Context

Frank Kane，2015 年《Self-Employment: Building an Internet Business of One》，Part III > Using Social Networks。研究本地文本本身，不推断外部链接内容已取得。

## Knowledge Point

本 KP 围绕渠道适配（channel fit）展开。作者要求从客户在哪里活动来决定投入，并把参与讨论与只发布公司宣传区分开。渠道带来经营价值的证据需要与投入时间一起看；书中的平台人群描述属于历史语境。

## Logical Path

1. 先定位客户活动
2. 再确认内容提供的价值
3. 最后比较结果和时间投入

## Key Terms

- 渠道适配（`channel fit`）：传播渠道与目标客户、内容及投入方式的匹配。

## Example

示意：某渠道持续耗费时间，却几乎没有相关访客或客户提及，应先检查适配性而非继续增加发帖量。这展示时间也属于渠道成本。

## Sources

- `AIP/preRaw/AIP-Materials/book.txt — Part III > Using Social Networks; lines 743–752; Windows-1252 decoding`：该段落支持中心判断、条件与例子；本 KP 保留其 2015 年写作语境。
