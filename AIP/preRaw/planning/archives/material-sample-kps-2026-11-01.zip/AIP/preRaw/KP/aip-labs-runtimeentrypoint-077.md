---
id: aip-labs-runtimeentrypoint-077
title: AgentCore 请求入口与响应封装
status: pending
sources:
- AIP/preRaw/AIP-Materials/AgentsLab/agentcore.py — lines 3–5 and 27–48, app, invoke,
  app.run
- AIP/preRaw/AIP-Materials/AgentsLab/strandsagent.py — lines 26–38
dependencies:
- aip-agentic-agentcore-024
- aip-labs-strandsinvocation-075
---

# aip-labs-runtimeentrypoint-077: AgentCore 请求入口与响应封装

## Learning Objective

能够追踪 AgentCore payload 中的 prompt 怎样进入 Strands，并说明返回 response 字段的来源及本例的会话边界。

## Scope

- Included: BedrockAgentCoreApp、entrypoint、payload 映射、代理实例生命周期和响应对象。
- Excluded: 云端创建流程、鉴权策略、并发压测与长期记忆配置。

## Source Context

agentcore.py 把本地代理组合放进 invoke 函数；与全局创建代理的 strandsagent.py 不同，它在每次入口执行时创建实例。

## Knowledge Point

运行时入口（runtime entrypoint）把服务请求转换为代理输入，再把结果转换为可返回的数据。示例从 payload.get("prompt", "") 取字符串，调用新建 Agent，并返回 {"response": str(result)}。context 没有参与逻辑，源码也未显式设置跨请求状态存储。

## Logical Path

1. 先定位 app 的创建与 @app.entrypoint 标记。
2. 从 payload 中取 prompt，核对缺失字段时的默认值。
3. 追踪本次入口中新建的 Agent 与执行结果。
4. 检查返回字段和 app.run()，明确请求处理与服务启动的分工。

## Key Terms

- 运行时入口（`runtime entrypoint`）：运行时接收请求后调用的应用处理函数。
- 请求载荷（`payload`）：传入处理函数的请求数据。

## Example

源码示例：传入 {"prompt": "Count prompt in prompts"} 后，invoke 取出 prompt 并将最终结果转成 response 文本；如果不提供 prompt，则传入空字符串。这个例子展示字段映射，并不证明已有参数校验或跨请求记忆。

## Sources

- `AIP/preRaw/AIP-Materials/AgentsLab/agentcore.py — lines 3–5 and 27–48, app, invoke, app.run`：请求入口、实例创建、字段映射与返回值。
- `AIP/preRaw/AIP-Materials/AgentsLab/strandsagent.py — lines 26–38`：本地版本在入口之外创建代理的对照。
