# AIP-Materials source validation and scope audit

Validated on 2026-11-01 (Australia/Sydney).
Learning root: `AIP/`. Requested source: `AIP/preRaw/AIP-Materials/`.

## Authorized scope

The user selected every file as study material, including the business book and bylaws, then explicitly narrowed `cfas-bylaws-rev-9.docx` to an AWS experiment sample document. The resulting plan studies the AWS labs, the complete locally supplied business-book text, the bundled license text and visual evidence in the three images. It does not teach the bylaws. No other source was silently excluded or moved.

Source files and the original KP definitions and approved notes remain unchanged. Definitions are planning state under `preRaw/KP/`; this audit is a source-to-objective map, not a progress ledger. Read KP frontmatter for current status. No lab, deployment, external communication, or model invocation was executed.

## Validation gate

- All 42 files are present and readable. Forty-one contain instructional content, supporting material or sample data; `.DS_Store` is operating-system metadata.
- All text is available locally. `book.txt` is Windows-1252, not UTF-8, and decodes completely into 926 lines. It contains the three parts, concluding material and numbered endnotes of the supplied text. Its source bytes were preserved.
- The DOCX ZIP passes its integrity check; `word/document.xml` parses completely. The supplied bylaws identify a September 10, 2022 revision and contain Articles I–XV and revision history. They remain sample data only.
- `SampleApp_Linux.zip` passes its integrity check. Each of its six files is identical to its expanded counterpart, so the duplicate packaging does not create duplicate learning objectives.
- All three JPEGs pass image validation, were fully decoded and visually inspected, and have their dimensions recorded in KP 155.
- Validation confirms access and apparent coverage of the specified local material, not factual accuracy or current operational readiness. URLs and publications referenced inside source files are references, not independently requested inputs; their full contents have not been imported.

## Source limits and code observations

- The book is Frank Kane's 2015 text. Personal anecdotes and historical statistics retain that attribution. The plan does not turn historical US legal, tax, health, credit or platform statements into present-day advice.
- The text refers to a flowchart and a landing-page screenshot that are not embedded in the TXT. The flowchart explicitly has a prose fallback; the page is described in prose. KPs use those text descriptions and do not claim access to the missing visual layouts. The financial projection table is an empty model, not a missing set of historical results. The cost labels near line 482 require separate verification; the plan does not adopt them as accounting definitions.
- Strands does not explicitly select a model or region in `strandsagent.py`. The pinned source requirements are evidence of package declarations, not proof those packages are installed.
- `squad_demo.py` imports `agent_squad`, absent from `requirements.txt`; its adapter invokes a shared global Strands agent synchronously and does not forward user/session/history parameters. The plan records these implementation boundaries.
- `weather.py` returns fixed weather text and does not convert units or call a real weather API. `count_keyword` counts substrings, not strictly delimited words.
- The Dockerfile's telemetry package constraint is unquoted in a shell-form RUN instruction; build parsing and telemetry configuration have not been executed or certified.
- `cdk/` contains two CDK import generations and corresponding step variants, rather than a generated complete project. The scripts describe scaffolding. Package/CLI installation, runtime values and deployment availability have not been verified against current services.
- The image Lambda calls `rekFunction` after its Records loop, so it processes only the last retained object in a multi-record event. This is captured as a code-reading boundary, without modifying source.
- The CodeBuild test is a string-presence gate. The CodeDeploy stop script has spaces around its assignment operator. The Node.js scheduled branch assigns `req.url` rather than comparing it. These examples were not represented as working production flows.
- CLI snippets contain sample account identifiers, region choices, a shard-iterator placeholder and a fixed SQS receipt handle. KPs explain their roles without reusing them or reproducing the long receipt string.
- The file named `eb-java-scorekeep-xray-simplified.yaml` actually declares an ECS-on-EC2 system. It declares an X-Ray daemon but does not supply application instrumentation source or live traces; application images remain external dependencies. Its existence is enough for static template study, not a completeness claim about a runnable application.
- Incorporated governance documents and Apache legal effectiveness are outside the imported source scope. The local license is studied as text; no legal compliance determination is made.

## Per-file source map

| Source relative to AIP-Materials | Bytes | Learning role / KP references |
|---|---:|---|
| `.DS_Store` | 8196 | Finder binary metadata; inventoried, no instructional objective |
| `AgentsLab/.dockerignore` | 759 | aip-labs-agentcontainer-078 |
| `AgentsLab/Dockerfile` | 811 | aip-labs-agentcontainer-078 |
| `AgentsLab/agentcore.py` | 1287 | aip-labs-runtimeentrypoint-077, aip-labs-agentcontainer-078 |
| `AgentsLab/requirements.txt` | 80 | aip-labs-strandsinvocation-075, aip-labs-agentcontainer-078, aip-labs-agentadapter-080 |
| `AgentsLab/squad_demo.py` | 4233 | aip-labs-agentrouting-079, aip-labs-agentadapter-080 |
| `AgentsLab/strandsagent.py` | 1623 | aip-labs-strandsinvocation-075, aip-labs-toolcontract-076, aip-labs-runtimeentrypoint-077 |
| `PromptChaining.json` | 325 | aip-labs-promptchain-082 |
| `api-gateway/lambda-code.py` | 266 | aip-labs-lambdaresponse-083 |
| `aws-cicd/codebuild/buildspec.yml` | 505 | aip-labs-buildgate-089 |
| `aws-cicd/codedeploy/SampleApp_Linux/LICENSE.txt` | 10884 | aip-materials-licensegrant-152, aip-materials-redistribution-153, aip-materials-licensewarranty-154 |
| `aws-cicd/codedeploy/SampleApp_Linux/appspec.yml` | 359 | aip-labs-deployhooks-090 |
| `aws-cicd/codedeploy/SampleApp_Linux/index.html` | 717 | aip-labs-deployhooks-090 |
| `aws-cicd/codedeploy/SampleApp_Linux/scripts/install_dependencies` | 34 | aip-labs-deployhooks-090 |
| `aws-cicd/codedeploy/SampleApp_Linux/scripts/start_server` | 33 | aip-labs-deployhooks-090 |
| `aws-cicd/codedeploy/SampleApp_Linux/scripts/stop_server` | 105 | aip-labs-deployhooks-090 |
| `aws-cicd/codedeploy/SampleApp_Linux.zip` | 5333 | Archive duplicate; all six members match the extracted directory byte for byte |
| `aws-cicd/codedeploy/commands.sh` | 279 | aip-labs-deployhooks-090 |
| `aws-cicd/nodejs-v2-blue/app.js` | 1149 | aip-labs-scheduledworker-091 |
| `aws-cicd/nodejs-v2-blue/cron.yaml` | 84 | aip-labs-scheduledworker-091 |
| `aws-cicd/nodejs-v2-blue/index.html` | 3054 | aip-labs-buildgate-089, aip-labs-scheduledworker-091 |
| `aws-cicd/nodejs-v2-blue/package.json` | 154 | aip-labs-scheduledworker-091 |
| `book.txt` | 264875 | aip-business-evidence-096, aip-business-inertia-097, aip-business-downside-098, aip-business-careerincentive-099, aip-business-workidentity-100, aip-business-supportfunctions-101, aip-business-scalability-102, aip-business-location-103, aip-business-schedule-104, aip-business-creativecontrol-105, aip-business-cashreserve-106, aip-business-healthbudget-107, aip-business-selfassessment-108, aip-business-businessobjective-109, aip-business-nichevalidation-110, aip-business-defensibility-111, aip-business-mission-112, aip-business-marketsizing-113, aip-business-mvp-114, aip-business-pricing-115, aip-business-revenuemodel-116, aip-business-businessstructure-117, aip-business-acquisitionplan-118, aip-business-projection-119, aip-business-sideproject-120, aip-business-naming-121, aip-business-bookkeeping-122, aip-business-launchtest-123, aip-business-contingency-124, aip-business-mentoring-125, aip-business-readiness-126, aip-business-professionalexit-127, aip-business-webbrief-128, aip-business-pressrelease-129, aip-business-adconversion-130, aip-business-adtargeting-131, aip-business-bannerads-132, aip-business-socialads-133, aip-business-offlineattribution-134, aip-business-seo-135, aip-business-landingpage-136, aip-business-email-137, aip-business-socialpresence-138, aip-business-measurement-139, aip-business-metricnoise-140, aip-business-salesfollowup-141, aip-business-ownership-142, aip-business-foundersales-143, aip-business-headcount-144, aip-business-timeallocation-145, aip-business-contractortrial-146, aip-business-productreuse-147, aip-business-portfolio-148, aip-business-transitionidentity-149, aip-business-energyandschedule-150, aip-business-lifestyleoutcome-151 |
| `cdk/images/kid_and_pigeons.jpeg` | 532065 | aip-materials-sceneevidence-155 |
| `cdk/images/penguins.jpeg` | 228891 | aip-materials-sceneevidence-155 |
| `cdk/images/swans.jpeg` | 295626 | aip-materials-sceneevidence-155 |
| `cdk/lambda/index.py` | 1476 | aip-labs-imagepipeline-088 |
| `cdk/lib/cdk-app-stack (1).js` | 2877 | aip-labs-cdksynthesis-087 |
| `cdk/lib/cdk-app-stack.js` | 2891 | aip-labs-cdksynthesis-087, aip-labs-imagepipeline-088 |
| `cdk/steps (1).sh` | 781 | aip-labs-cdksynthesis-087 |
| `cdk/steps.sh` | 642 | aip-labs-cdksynthesis-087 |
| `cfas-bylaws-rev-9.docx` | 35220 | Sample document only, per explicit user clarification; no bylaws KPs |
| `cli/ec2-metadata.sh` | 78 | aip-labs-instancemetadata-085 |
| `cloudformation/0-just-ec2.yaml` | 175 | aip-labs-stackreferences-086 |
| `cloudformation/1-ec2-with-sg-eip.yaml` | 1233 | aip-labs-stackreferences-086 |
| `ec2-fundamentals/ec2-user-data.sh` | 258 | aip-labs-ec2bootstrap-084 |
| `kinesis/kinesis-data-streams.sh` | 559 | aip-labs-sharditerator-092 |
| `kms/ExampleSecretFile.txt` | 19 | aip-labs-kmsblob-094 |
| `kms/kms-demo-cli.sh` | 815 | aip-labs-kmsblob-094 |
| `sqs/sqs.sh` | 1263 | aip-labs-queuereceipt-093 |
| `weather.py` | 1283 | aip-labs-actionresponse-081 |
| `x-ray/eb-java-scorekeep-xray-simplified.yaml` | 16316 | aip-labs-xraysidecar-095 |

## Knowledge-point objectives

These are new, distinct reading or code-tracing objectives. Existing IDs retain their original identity, content and status. Numbers preserve a source-oriented order; prerequisite links, rather than numbering alone, determine eligibility. The existing Mode 1 map has not been regenerated.

| KP | Objective |
|---|---|
| [aip-labs-strandsinvocation-075](../KP/aip-labs-strandsinvocation-075.md) | Strands 单次请求的代码执行路径 |
| [aip-labs-toolcontract-076](../KP/aip-labs-toolcontract-076.md) | 自定义 Strands 工具的输入输出契约 |
| [aip-labs-runtimeentrypoint-077](../KP/aip-labs-runtimeentrypoint-077.md) | AgentCore 请求入口与响应封装 |
| [aip-labs-agentcontainer-078](../KP/aip-labs-agentcontainer-078.md) | 代理容器的构建内容与启动命令 |
| [aip-labs-agentrouting-079](../KP/aip-labs-agentrouting-079.md) | Agent Squad 按职责路由请求 |
| [aip-labs-agentadapter-080](../KP/aip-labs-agentadapter-080.md) | 将 Strands 结果适配为 Agent Squad 消息 |
| [aip-labs-actionresponse-081](../KP/aip-labs-actionresponse-081.md) | Bedrock 函数型 Action Group 的 Lambda 消息契约 |
| [aip-labs-promptchain-082](../KP/aip-labs-promptchain-082.md) | 提示链中后续步骤的上下文依赖 |
| [aip-labs-lambdaresponse-083](../KP/aip-labs-lambdaresponse-083.md) | API Gateway Lambda 代理响应的序列化边界 |
| [aip-labs-ec2bootstrap-084](../KP/aip-labs-ec2bootstrap-084.md) | EC2 User Data 的服务初始化路径 |
| [aip-labs-instancemetadata-085](../KP/aip-labs-instancemetadata-085.md) | 从实例内查询 EC2 元数据 |
| [aip-labs-stackreferences-086](../KP/aip-labs-stackreferences-086.md) | CloudFormation 通过资源引用连接部署对象 |
| [aip-labs-cdksynthesis-087](../KP/aip-labs-cdksynthesis-087.md) | CDK 从构造代码到 CloudFormation 模板 |
| [aip-labs-imagepipeline-088](../KP/aip-labs-imagepipeline-088.md) | S3 图片事件到标签持久化的数据路径 |
| [aip-labs-buildgate-089](../KP/aip-labs-buildgate-089.md) | CodeBuild 用命令退出结果形成构建门禁 |
| [aip-labs-deployhooks-090](../KP/aip-labs-deployhooks-090.md) | CodeDeploy 部署包与生命周期钩子的对应关系 |
| [aip-labs-scheduledworker-091](../KP/aip-labs-scheduledworker-091.md) | 定时任务通过 HTTP POST 进入工作进程 |
| [aip-labs-sharditerator-092](../KP/aip-labs-sharditerator-092.md) | Kinesis 从写入记录到分片迭代读取 |
| [aip-labs-queuereceipt-093](../KP/aip-labs-queuereceipt-093.md) | SQS 接收与删除之间的收据句柄 |
| [aip-labs-kmsblob-094](../KP/aip-labs-kmsblob-094.md) | KMS CLI 的加密结果与 Base64 编码层 |
| [aip-labs-xraysidecar-095](../KP/aip-labs-xraysidecar-095.md) | ECS 任务中的 X-Ray 采集容器 |
| [aip-business-evidence-096](../KP/aip-business-evidence-096.md) | 区分商业自述、建议与外部证据 |
| [aip-business-inertia-097](../KP/aip-business-inertia-097.md) | 识别职业惯性对选择的影响 |
| [aip-business-downside-098](../KP/aip-business-downside-098.md) | 用退出条件界定创业试验的损失边界 |
| [aip-business-careerincentive-099](../KP/aip-business-careerincentive-099.md) | 比较未来职业奖励中的不确定性 |
| [aip-business-workidentity-100](../KP/aip-business-workidentity-100.md) | 职业身份变化与社交支持 |
| [aip-business-supportfunctions-101](../KP/aip-business-supportfunctions-101.md) | 识别离开雇主后需要承接的支持职能 |
| [aip-business-scalability-102](../KP/aip-business-scalability-102.md) | 可复制产品与按小时收费的扩展边界 |
| [aip-business-location-103](../KP/aip-business-location-103.md) | 工作地点自主权与业务交付方式 |
| [aip-business-schedule-104](../KP/aip-business-schedule-104.md) | 时间自主权与客户响应承诺 |
| [aip-business-creativecontrol-105](../KP/aip-business-creativecontrol-105.md) | 客户与投资关系对经营自主权的约束 |
| [aip-business-cashreserve-106](../KP/aip-business-cashreserve-106.md) | 阅读书中的现金储备与求职缓冲模型 |
| [aip-business-healthbudget-107](../KP/aip-business-healthbudget-107.md) | 把医疗保障转换纳入成本模型 |
| [aip-business-selfassessment-108](../KP/aip-business-selfassessment-108.md) | 把创业自评表当作能力缺口清单 |
| [aip-business-businessobjective-109](../KP/aip-business-businessobjective-109.md) | 增长型企业与生活方式企业的目标差异 |
| [aip-business-nichevalidation-110](../KP/aip-business-nichevalidation-110.md) | 从未被满足的需求识别可付费细分市场 |
| [aip-business-defensibility-111](../KP/aip-business-defensibility-111.md) | 产品差异怎样形成复制门槛 |
| [aip-business-mission-112](../KP/aip-business-mission-112.md) | 用使命与可衡量目标约束商业计划 |
| [aip-business-marketsizing-113](../KP/aip-business-marketsizing-113.md) | 自下而上的市场规模估算 |
| [aip-business-mvp-114](../KP/aip-business-mvp-114.md) | 最小可行产品的范围与质量边界 |
| [aip-business-pricing-115](../KP/aip-business-pricing-115.md) | 从客户价值与替代方案推导定价问题 |
| [aip-business-revenuemodel-116](../KP/aip-business-revenuemodel-116.md) | 一次性销售与订阅的收入时间结构 |
| [aip-business-businessstructure-117](../KP/aip-business-businessstructure-117.md) | 区分经营组织形式与税务处理问题 |
| [aip-business-acquisitionplan-118](../KP/aip-business-acquisitionplan-118.md) | 把客户发现与购买连接成获客路径 |
| [aip-business-projection-119](../KP/aip-business-projection-119.md) | 商业预测中的规模、渗透率与成本假设 |
| [aip-business-sideproject-120](../KP/aip-business-sideproject-120.md) | 在保留主业时验证产品假设 |
| [aip-business-naming-121](../KP/aip-business-naming-121.md) | 企业命名中的易记性与可用性 |
| [aip-business-bookkeeping-122](../KP/aip-business-bookkeeping-122.md) | 业务收支记录与个人收支分离 |
| [aip-business-launchtest-123](../KP/aip-business-launchtest-123.md) | 软发布前预先定义成功指标 |
| [aip-business-contingency-124](../KP/aip-business-contingency-124.md) | 经营转换中的备用路径与触发条件 |
| [aip-business-mentoring-125](../KP/aip-business-mentoring-125.md) | 按业务相似性筛选创业建议 |
| [aip-business-readiness-126](../KP/aip-business-readiness-126.md) | 离职前检查表作为跨条件一致性检查 |
| [aip-business-professionalexit-127](../KP/aip-business-professionalexit-127.md) | 职业退出过程中的关系与交接 |
| [aip-business-webbrief-128](../KP/aip-business-webbrief-128.md) | 网站委托中的需求表达与可维护性 |
| [aip-business-pressrelease-129](../KP/aip-business-pressrelease-129.md) | 面向特定读者组织新闻稿 |
| [aip-business-adconversion-130](../KP/aip-business-adconversion-130.md) | 用付费行动成本检查广告目标 |
| [aip-business-adtargeting-131](../KP/aip-business-adtargeting-131.md) | 搜索意图与广告投放范围的匹配 |
| [aip-business-bannerads-132](../KP/aip-business-bannerads-132.md) | 横幅广告从展示量到交易的估算链 |
| [aip-business-socialads-133](../KP/aip-business-socialads-133.md) | 把社交互动与广告带来的购买分开 |
| [aip-business-offlineattribution-134](../KP/aip-business-offlineattribution-134.md) | 线下营销的来源识别 |
| [aip-business-seo-135](../KP/aip-business-seo-135.md) | 自然搜索内容与查询意图的对应关系 |
| [aip-business-landingpage-136](../KP/aip-business-landingpage-136.md) | 落地页围绕一个有价值的动作组织内容 |
| [aip-business-email-137](../KP/aip-business-email-137.md) | 邮件活动中的订阅关系与发送质量 |
| [aip-business-socialpresence-138](../KP/aip-business-socialpresence-138.md) | 社交渠道选择中的时间机会成本 |
| [aip-business-measurement-139](../KP/aip-business-measurement-139.md) | 把营销指标连接到可采取的动作 |
| [aip-business-metricnoise-140](../KP/aip-business-metricnoise-140.md) | 小样本营销数据中的随机波动与代理指标 |
| [aip-business-salesfollowup-141](../KP/aip-business-salesfollowup-141.md) | 销售线索的记录与自动跟进 |
| [aip-business-ownership-142](../KP/aip-business-ownership-142.md) | 帮助承诺与长期所有权交换的差异 |
| [aip-business-foundersales-143](../KP/aip-business-foundersales-143.md) | 把线索搜集与技术成交分开 |
| [aip-business-headcount-144](../KP/aip-business-headcount-144.md) | 员工人数与生活方式企业目标的区别 |
| [aip-business-timeallocation-145](../KP/aip-business-timeallocation-145.md) | 用机会成本比较自动化、外包与产品开发 |
| [aip-business-contractortrial-146](../KP/aip-business-contractortrial-146.md) | 用小任务验证外部承包者的交付 |
| [aip-business-productreuse-147](../KP/aip-business-productreuse-147.md) | 从现有客户与资产寻找新产品 |
| [aip-business-portfolio-148](../KP/aip-business-portfolio-148.md) | 持续产品组合与旧产品衰退 |
| [aip-business-transitionidentity-149](../KP/aip-business-transitionidentity-149.md) | 把过去职业经验重新纳入创业叙事 |
| [aip-business-energyandschedule-150](../KP/aip-business-energyandschedule-150.md) | 按精力和交付安排工作而非填满时段 |
| [aip-business-lifestyleoutcome-151](../KP/aip-business-lifestyleoutcome-151.md) | 用生活质量回看经营目标 |
| [aip-materials-licensegrant-152](../KP/aip-materials-licensegrant-152.md) | Apache 2.0 文本中的授权对象与边界 |
| [aip-materials-redistribution-153](../KP/aip-materials-redistribution-153.md) | Apache 2.0 文本中的再分发条件 |
| [aip-materials-licensewarranty-154](../KP/aip-materials-licensewarranty-154.md) | 代码使用许可与服务保证的区别 |
| [aip-materials-sceneevidence-155](../KP/aip-materials-sceneevidence-155.md) | 图像描述中的可见事实与推断 |
