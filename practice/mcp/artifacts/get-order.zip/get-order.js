"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const handler = async (event) => {
    if (typeof event?.order_id !== "string" ||
        event.order_id.trim() === "") {
        return {
            ok: false,
            error: {
                code: "INVALID_INPUT",
                message: "order_id must be a non-empty string",
            },
        };
    }
    if (event.order_id !== "ORDER-001") {
        return {
            ok: false,
            error: {
                code: "NOT_FOUND",
                message: "Order not found",
            },
        };
    }
    return {
        ok: true,
        order: {
            order_id: "ORDER-001",
            status: "pending",
            amount: 99,
            currency: "AUD",
        },
    };
};
exports.handler = handler;
